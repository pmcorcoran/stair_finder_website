Stair Finder!

To use the stairfinder website first you need an api key from google.
Go to https://cloud.google.com/maps-platform/pricing annd click get started.
You will nedd to make an account and sign up for the free trial.

When signing up for the free trial you will be asked which of maps,
routes, and places you would like access to. Select all possible options.
Once you have signed up you will have an api key.

Next you will need to download this project's files into a directory.
Once you've done that. In the terminal window go to that directory.
Change directories to staircase by running: cd staircase
Once you are in staircase run: export API_KEY=your_api_key
where your_api_key is the one you got from google.
Next run: flask run

Now your terminal have a link starting with https://
Click and open that link.

You will be on the login page for Stair Finder!
If you do not have an account yet, you probably don't since you are here.
In the upper right hand corner click register. Fill in the required fields and
submit it. You will now be on the log in page. Login to the account you just
created.

Now that you have logged in you will be brought to the search page.
In the text box type an address or location where you would like to find nearby
stairs. You will be brought to a page with a map centered on the location you just
enntered. If you do not see any pins markinng nearby staircases zoom out.
Below the map there will be a list of addresses of the 10 closest staircases.

In the upper left hand corner you will see a link called Add Stairs.
Click that link and you will be brought to a page similar to the search page.
On this page you can enter an location where a staircase is located. When you
enter a location and click add, you will be brought to a page with a map and a
pin placed on the location of the staircase you just added.
Now that you have added a staircase it is in the database The next time you
search for a staircase the one you added could be a result if it is one of the 10
closest to the search location.





