For the Stair Finder web app. I used python, flask, html css and javascript,
sqlite, and the google maps apis. I used a very similar structure to the
cs50 finance assignment we had.

The directory structure is exactly the same is cs50 finance. In the
static folder there is a styles.css file with css code, most of which is very
similar to cs50 finance.

In the templates folder there are all the html pages for the project.
They all extend layout.html, which is slightly modified from cs50 finance.

In the main staircase folder where the static and template folders are also held,
there are stairs.db, helpers.py, and application.py.

stairs.db contains 3 tables. A users table that stores the users username,
password hash, and an id which is the primary key.
A locations table which has an id primary key columnn, a latitude column
which stores the latitude by type TEXT. A longitude column which is the same
as the latitude but for longitude. And a user_id column which is a foreign key
that stores the id of the user who entered the location, it maps to the id
primary key of the users table.
And a photos table which is not currently in use but will store an id primary
key column, a photo as a blob datatype, and a user_id which will be a foreign
key that maps to the primary key is of the users table. I plan on improving this
website further and deploying it with heroku.

helpers.py has functions called in application.py
One is login_required() which we used in cs50 finance.
Then there is get_coord(address) which takes ann address and calls the google
geocoding api and converts it into the coordinates and returns the coordinates
as a dict.
There is also get_add(coord) which takes coordinates as a string or list
with the list having latitude first and calls the google reverse geocoding api
to get the address and returns the address as a string.

application.py works similarly to how it did in cs50.
There is login() logout() annd register() which are just like cs50.
Then there is search() which brings the user to a page to search an address if they
got there via GET i.e. after login or by clicking search in the nav bar. When a user searches
an address then search() renders a searched.html template which displays a map
centered over the searched location and below that a list of up to the 10
closest staircases.
Then there is addstairs() which if you get there via GET i.e. the nav bar you
are brought to a page like search where you can enter a location and add it to
the stairs.db (and the map). When you do that it renders a template added.html
which shows the user a map with a pin on the location they entered.